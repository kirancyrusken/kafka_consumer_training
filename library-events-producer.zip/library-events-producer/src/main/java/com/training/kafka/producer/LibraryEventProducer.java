package com.training.kafka.producer;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.training.kafka.domain.LibraryEvent;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class LibraryEventProducer {

	@Autowired
	KafkaTemplate<Integer, String> kafkaTemplate;

	@Autowired
	ObjectMapper objectMapper;

	public void sendLibraryEvent(LibraryEvent event) throws JsonProcessingException {

		Integer key = event.getLibraryEventId();
		String value = objectMapper.writeValueAsString(event);

		ListenableFuture<SendResult<Integer, String>> lf = kafkaTemplate.sendDefault(key, value);
		lf.addCallback(new ListenableFutureCallback<SendResult<Integer, String>>() {

			@Override
			public void onSuccess(SendResult<Integer, String> result) {
				handleSuccess(key, value, result);

			}

			@Override
			public void onFailure(Throwable ex) {

				handleFailure(key, value, ex);
			}

		});
	}

	public ListenableFuture<SendResult<Integer, String>> sendLibraryEventToTopic(LibraryEvent event) throws JsonProcessingException {

		Integer key = event.getLibraryEventId();
		String value = objectMapper.writeValueAsString(event);

		ListenableFuture<SendResult<Integer, String>> lf = kafkaTemplate.send("t_LibraryEvents",key, value);
		lf.addCallback(new ListenableFutureCallback<SendResult<Integer, String>>() {

			@Override
			public void onSuccess(SendResult<Integer, String> result) {
				handleSuccess(key, value, result);

			}

			@Override
			public void onFailure(Throwable ex) {

				handleFailure(key, value, ex);
			}

		});
		return lf;
	}
	
	public ListenableFuture<SendResult<Integer, String>> sendLibraryEventToTopicUsingProducerRecord(LibraryEvent event) throws JsonProcessingException {

		Integer key = event.getLibraryEventId();
		String value = objectMapper.writeValueAsString(event);
		
		ProducerRecord<Integer, String> pr = buildProducerRecord(key, value, "t_LibraryEvents");
		ListenableFuture<SendResult<Integer, String>> lf = kafkaTemplate.send(pr);
		lf.addCallback(new ListenableFutureCallback<SendResult<Integer, String>>() {

			@Override
			public void onSuccess(SendResult<Integer, String> result) {
				handleSuccess(key, value, result);

			}

			@Override
			public void onFailure(Throwable ex) {

				handleFailure(key, value, ex);
			}

		});
		return lf;
	}

	public SendResult<Integer, String> sendLibraryEventSync(LibraryEvent event)
			throws ExecutionException, InterruptedException, JsonProcessingException {
		Integer key = event.getLibraryEventId();
		String value = objectMapper.writeValueAsString(event);
		SendResult<Integer, String> sr = null;
		try {
			sr = kafkaTemplate.sendDefault(key, value).get();
		} catch (InterruptedException | ExecutionException e) {
			log.error("InterruptedException or ExecutionException Error sending the message with exception {}",
					e.getMessage());
			throw e;
		} catch (Exception ex) {
			throw ex;
		}

		return sr;
	}

	protected void handleFailure(Integer key, String value, Throwable ex) {

		log.error("Error sending the message with exception {}", ex.getMessage());
		try {
			throw ex;
		} catch (Throwable throwable) {
			log.error("Error in OnFailure {}", throwable.getMessage());
		}
	}

	protected void handleSuccess(Integer key, String value, SendResult<Integer, String> result) {
		log.info("Message sent successfully for the key {}, value {}. Partition {}", key, value,
				result.getRecordMetadata().partition());

	}
	
	private ProducerRecord<Integer, String> buildProducerRecord(Integer key, String value, String topic){
		return new ProducerRecord<Integer, String>(topic, null, key, value, null);
	}
}
