package com.training.kafka.domain;

public enum LibraryEventType {
	
	NEW,
	UPDATE

}
