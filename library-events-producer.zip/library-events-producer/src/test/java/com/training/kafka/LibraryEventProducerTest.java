package com.training.kafka;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.when;

import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.TopicPartition;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.SettableListenableFuture;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.training.kafka.domain.Book;
import com.training.kafka.domain.LibraryEvent;
import com.training.kafka.producer.LibraryEventProducer;

@ExtendWith(MockitoExtension.class)
public class LibraryEventProducerTest {

	@Mock
	KafkaTemplate<Integer, String> kt;

	@InjectMocks
	LibraryEventProducer lep;

	@Spy
	ObjectMapper objectMapper = new ObjectMapper();

	@Test
	void sendLibraryEventToTopicUsingProducerRecord_failure() throws JsonProcessingException {

		Book book = Book.builder().bookId(123).bookAuthor("Christopher").bookName("Nothing").build();
		LibraryEvent lb = LibraryEvent.builder().libraryEventId(null).book(book).build();
		SettableListenableFuture slf = new SettableListenableFuture();
		slf.setException(new Exception("Exception callin Kafka"));

		when(kt.send(isA(ProducerRecord.class))).thenReturn(slf);
		lep.sendLibraryEventToTopicUsingProducerRecord(lb);

		assertThrows(Exception.class, () -> lep.sendLibraryEventToTopicUsingProducerRecord(lb).get());
	}

	@Test
	void sendLibraryEventToTopicUsingProducerRecord_success() throws JsonProcessingException, InterruptedException, ExecutionException {
		Book book = Book.builder().bookId(123).bookAuthor("Christopher").bookName("Nothing").build();
		LibraryEvent lb = LibraryEvent.builder().libraryEventId(null).book(book).build();

		String valueInJson = objectMapper.writeValueAsString(lb);

		SettableListenableFuture slf = new SettableListenableFuture();
		ProducerRecord<Integer, String> pr = new ProducerRecord<>("t_LibraryEvents_test", lb.getLibraryEventId(),
				valueInJson);
		
		RecordMetadata rm = new RecordMetadata(new TopicPartition("t_LibraryEvents_test", 1),1,1,342,System.currentTimeMillis(), 1,2);
		SendResult<Integer, String> sr = new SendResult<>(pr, rm);
		
		slf.set(sr);
		
		SendResult<Integer, String> sr1 = (SendResult<Integer, String>) slf.get();
		
		assert sr1.getRecordMetadata().partition() == 1;

	}
}
