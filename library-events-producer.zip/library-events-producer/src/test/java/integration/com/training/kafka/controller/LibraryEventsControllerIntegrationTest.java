package integration.com.training.kafka.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.IntegerDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.kafka.test.utils.KafkaTestUtils;
import org.springframework.test.context.TestPropertySource;

import com.training.kafka.LibraryEventsProducerApplication;
import com.training.kafka.domain.Book;
import com.training.kafka.domain.LibraryEvent;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, classes = LibraryEventsProducerApplication.class)
@EmbeddedKafka(topics = { "t_LibraryEvents" }, partitions = 3)
@TestPropertySource(properties = { "spring.kafka.producer.bootstrap-servers=${spring.embedded.kafka.brokers}",
		"spring.kafka.admin.properties.bootstrap.servers=${spring.embedded.kafka.brokers}" })
public class LibraryEventsControllerIntegrationTest {

	@Autowired
	TestRestTemplate restTemplate;

	@Autowired
	EmbeddedKafkaBroker embeddedkafkaBroker;

	private Consumer<Integer, String> consumer;

	@BeforeEach
	void Setup() {
		Map<String, Object> configs = new HashMap<>(
				KafkaTestUtils.consumerProps("testGroup", "true", embeddedkafkaBroker));
		consumer = new DefaultKafkaConsumerFactory<>(configs, new IntegerDeserializer(), new StringDeserializer())
				.createConsumer();
		embeddedkafkaBroker.consumeFromAllEmbeddedTopics(consumer);
	}

	@AfterEach
	void tearDown() {
		consumer.close();
	}

	@Test
	@Timeout(5)
	void postLIbraryEvent() {

		Book book = Book.builder().bookId(123).bookAuthor("Christopher").bookName("Nothing").build();
		LibraryEvent lb = LibraryEvent.builder().libraryEventId(null).book(book).build();

		HttpHeaders headers = new HttpHeaders();
		headers.set("content-type", MediaType.APPLICATION_JSON.toString());
		HttpEntity<LibraryEvent> request = new HttpEntity<>(lb);

		ResponseEntity<LibraryEvent> response = restTemplate.exchange("/v1/libraryevent", HttpMethod.POST, request,
				LibraryEvent.class);

		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		
		ConsumerRecord<Integer, String> cr = KafkaTestUtils.getSingleRecord(consumer, "t_LibraryEvents");
		
		String expectedValue = "{\"libraryEventId\":null,\"book\":{\"bookId\":123,\"bookName\":\"Nothing\",\"bookAuthor\":\"Christopher\"},\"eventType\":\"NEW\"}";
		
		String value = cr.value();
		assertEquals(expectedValue, value);
		
	}
	
	@Test
	@Timeout(5)
	void updateLibraryEvent() {
		
		Book book = Book.builder().bookId(123).bookAuthor("Christopher").bookName("Nothing").build();
		LibraryEvent lb = LibraryEvent.builder().libraryEventId(123).book(book).build();

		HttpHeaders headers = new HttpHeaders();
		headers.set("content-type", MediaType.APPLICATION_JSON.toString());
		HttpEntity<LibraryEvent> request = new HttpEntity<>(lb);

		ResponseEntity<LibraryEvent> response = restTemplate.exchange("/v1/libraryevent", HttpMethod.PUT, request,
				LibraryEvent.class);
		
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

}
