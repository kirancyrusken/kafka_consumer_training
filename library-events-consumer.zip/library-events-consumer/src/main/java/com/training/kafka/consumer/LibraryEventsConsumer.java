package com.training.kafka.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class LibraryEventsConsumer {
	
	@KafkaListener(topics = {"t_LibraryEvents"})
	public void onMessage(ConsumerRecord<Integer, String> cr) {
		log.info("Consumer Record : {}", cr);
	}

}
